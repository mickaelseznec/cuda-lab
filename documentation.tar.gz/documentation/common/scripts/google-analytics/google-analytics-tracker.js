try {
    var pageTracker = _gat._getTracker("UA-1273456-56");
    pageTracker._trackPageview();
} catch(err) {}
