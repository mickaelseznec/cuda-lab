if(document.location.protocol=='http:'){
var Tynt=Tynt||[];Tynt.push('aBENEGgL0r44W6acwqm_6r');
(function(){var s=document.createElement('script');s.async="async";s.type="text/javascript";s.src='http://tcr.tynt.com/ti.js';var h=document.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);})();
}

